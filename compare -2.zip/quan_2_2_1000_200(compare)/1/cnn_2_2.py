import sys
import random
import numpy as np
from flatbuffers.packer import float32

# import tensorflow as tf
# from tensorflow import keras

# from tensorflow.keras.models import Sequential
# from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
# from tensorflow.keras.utils import to_categorical

from qiskit import QuantumCircuit, Aer, execute
from msgpack_numpy import tostr
import torch
import torch.nn.functional as F



def q_circuit(x):
    # sum=0
    # for i in range(9):
    #     sum=sum+x[i]
    # return  sum/9

    # 创建一个包含 4 个量子比特和 4 个经典比特的量子电路
    qc = QuantumCircuit(4, 4)

    for qubit in range(4):
        qc.rx(x[qubit],qubit)  # U(θ, φ, λ) 作用于量子比特 qubit

    qc.cx(0, 1)
    qc.cx(1, 2)
    qc.cx(2, 3)

    qc.measure([0, 1, 2, 3], [0, 1, 2, 3])

    # 使用 Qiskit 的模拟器执行电路
    simulator = Aer.get_backend('qasm_simulator')

    # 执行电路并获取结果
    job = execute(qc, simulator, shots=1024)

    # 获取结果
    result = job.result()

    # 获取测量结果
    counts = result.get_counts(qc)

    f0=9.923e-1
    f1=1.26e-2
    f2=1.37e-2
    f3=1.12e-2

    # 计算每个量子比特的期望值
    P_0 = sum(counts.get(result, 0) for result in counts if result[3] == '1') / 1024 #获取第四个量子比特期望值
    P_1 = sum(counts.get(result, 0) for result in counts if result[2] == '1') / 1024  # 获取第四个量子比特期望值
    P_2 = sum(counts.get(result, 0) for result in counts if result[1] == '1') / 1024  # 获取第四个量子比特期望值
    P_3 = sum(counts.get(result, 0) for result in counts if result[0] == '1') / 1024  # 获取第四个量子比特期望值
    P=np.pi*(P_0*f0+P_1*f1+P_2*f2+P_3*f3)

    return P



def main():
    #设置随机种子
    # random.seed(42)
    # np.random.seed(42)
    #tf.random.set_seed(42)
    # from tensorflow.keras.datasets import mnist
    # # 加载MNIST数据集
    # (train_images, train_labels), (test_images, test_labels) = mnist.load_data()
    #
    # # 数据预处理
    # train_images = train_images.reshape((60000, 28, 28, 1))
    # #train_images = train_images.astype('float32') / 255
    # test_images = test_images.reshape((10000, 28, 28, 1))
    # #test_images = test_images.astype('float32') / 255
    #
    # # train_labels = to_categorical(train_labels)
    # # test_labels = to_categorical (test_labels )
    # # train_filter = np.isin(train_labels, [0, 1, 2, 3,4,5])
    # # test_filter = np.isin(test_labels, [0, 1, 2, 3,4,5])
    #
    # # train_images = train_images[train_filter]
    # # train_labels = train_labels[train_filter]
    # # test_images = test_images[test_filter]
    # # test_labels = test_labels[test_filter]
    #
    # train_images = train_images[:1000]
    # train_labels = train_labels[:1000]
    # test_images = test_images[:200]
    # test_labels = test_labels[:200]
    #
    # np.save("train_images", train_images)
    # np.save("train_labels", train_labels)
    # np.save("test_images ", test_images)
    # np.save("test_labels ", test_labels)
    #
    # #print(train_labels)
    #
    # # print("train")
    # # from collections import Counter
    # # # 统计每个标签的出现次数
    # # label_counts = Counter(train_labels)
    # #
    # # # 输出每个标签对应的出现次数
    # # for label, count in label_counts.items():
    # #     print(f"标签 {label}: {count} 次")
    # # print("test")
    # # label_counts = Counter(test_labels)
    # #
    # # # 输出每个标签对应的出现次数
    # # for label, count in label_counts.items():
    # #     print(f"标签 {label}: {count} 次")
    #
    # sys.exit()

    # 000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000

    train_images  =  np.load("train_images.npy")
    test_images   =  np.load("test_images .npy")

    # 初始化输出张量

    # ra=np.zeros((1000, 28, 28, 1))
    # for i in range(1000):
    #     ro = np.flip(np.flip(train_images[i], axis=0), axis=1)
    #     ra[i]=ro
    # train_images=np.concatenate((train_images, ra), axis=0)

    train_images = torch.tensor(train_images, dtype=torch.float32)
    test_images = torch.tensor(test_images, dtype=torch.float32)
    train_images = train_images.permute(0, 3, 1, 2)
    test_images = test_images.permute(0, 3, 1, 2)

    train_images = F.avg_pool2d(train_images, kernel_size=6, stride=2, padding=0, count_include_pad=False)#.view(bsz, 4, 4)
    test_images  = F.avg_pool2d(test_images, kernel_size=6, stride=2, padding=0, count_include_pad=False)#.view(bsz, 4, 4)

    train_images = (train_images - torch.min(train_images)) / (torch.max(train_images) - torch.min(train_images)) * (np.pi)
    test_images  = (test_images - torch.min(test_images)) / (torch.max(test_images) - torch.min(test_images)) * (np.pi)

    #batch_size, height, width, channels = train_images.shape

    # 设置卷积核大小为 2x2，步长为 1
    ksize = (2, 2)
    stride = 1

    # print(train_images[0])
    # sys.exit()


    conv_output = np.zeros((1000, 1, 12, 12))
    conv_output2 = np.zeros((200, 1, 12, 12))

    for i in range(train_images.shape[0]):  # 遍历 500 个样本
        for j in range(train_images.shape[2]):  # 遍历每个 4x4 图像的行（去除边界，处理 2x2 区域）
            for k in range(train_images.shape[3]):  # 遍历每个 4x4 图像的列（去除边界，处理 2x2 区域）
                # 提取 2x2 区域
                input_region = train_images[i, 0, j:j + 2, k:k + 2]  # 取出 2x2 区域
                input_region=torch.flatten(input_region)
                input_region=input_region.view(-1)

                if j >= train_images.shape[2] - 1 or k >= train_images.shape[3] - 1:
                    conv_output[i, 0, j, k] = float(input_region[0])  # 无法凑齐一个卷积，避免降维损失信息，使用类有效卷积方案
                else:
                    # 使用 q_circuit 函数计算卷积结果
                    conv_output[i, 0, j, k] =q_circuit(
                        [float(input_region[0]), float(input_region[1]), float(input_region[2]),
                         float(input_region[3])])  # 存储卷积后的结果


    np.save("train_i_k2*2.npy", conv_output)

    for i in range(test_images.shape[0]):  # 遍历 500 个样本
        for j in range(test_images.shape[2]):  # 遍历每个 4x4 图像的行（去除边界，处理 2x2 区域）
            for k in range(test_images.shape[3]):  # 遍历每个 4x4 图像的列（去除边界，处理 2x2 区域）
                # 提取 2x2 区域
                input_region = test_images[i, 0, j:j + 2, k:k + 2]  # 取出 2x2 区域
                input_region=torch.flatten(input_region)
                input_region=input_region.view(-1)

                if j >= train_images.shape[2] - 1 or k >= train_images.shape[3] - 1:
                    conv_output2[i, 0, j, k] = float(input_region[0])  # 无法凑齐一个卷积，但为了避免降维损失信息，使用类有效卷积方案
                else:
                    # 使用 q_circuit 函数计算卷积结果
                    conv_output2[i, 0, j, k] = q_circuit(
                        [float(input_region[0]), float(input_region[1]), float(input_region[2]),
                         float(input_region[3])])  # 存储卷积后的结果


    np.save("test_i_k2*2.npy", conv_output2)
    print("convert_finished")
    sys.exit()

    # for b in range(batch_size):
    #     for i in range(0, 4, 2):
    #         for j in range(0, 4, 2):
    #             # 获取 2x2 的区域
    #             patch=[float(train_images[b][0][i][j]),float(train_images[b][0][i][j+1]),float(train_images[b][0][i+1][j]),float(train_images[b][0][i+1][j+1])]
    #             # 传递该区域到 q_circuit 函数进行卷积
    #             [conv_output[b][0][i][j],conv_output[b][0][i][j+1],conv_output[b][0][i+1][j],conv_output[b][0][i+1][j+1] ]= q_circuit(patch)
    #
    # np.save("train_i",conv_output)
    #
    # for b in range(100):
    #     for i in range(0, 4, 2):
    #         for j in range(0, 4, 2):
    #             # 获取 2x2 的区域
    #             patch=[float(test_images[b][0][i][j]),float(test_images[b][0][i][j+1]),float(test_images[b][0][i+1][j]),float(test_images[b][0][i+1][j+1])]
    #             # 传递该区域到 q_circuit 函数进行卷积
    #             [conv_output2[b][0][i][j],conv_output2[b][0][i][j+1],conv_output2[b][0][i+1][j],conv_output2[b][0][i+1][j+1] ]= q_circuit(patch)
    # np.save("test_i",conv_output2)
    # sys.exit()




    # 转换为 TensorFlow 张量
    conv_output = tf.convert_to_tensor(conv_output, dtype=tf.float32)

    # 000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
    train_labels = to_categorical(train_labels)
    test_labels = to_categorical(test_labels)

    # 构建卷积神经网络模型
    model = Sequential()
    # model.add(Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1))) #卷积
    # model.add(MaxPooling2D((2, 2))) #池化，降低图像尺寸
    model.add(Flatten())  # 一维化，模型输入
    model.add(Dense(8000, activation='relu'))
    model.add(Dense(4, activation='softmax'))

    # 编译模型
    model.compile(optimizer='adam',
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])


    #输入数据格式应该是numpy(50,28,28,1)
    model.fit(train_images, train_labels, epochs=10, batch_size=64, validation_split=0.1)

    # 保存模型
    # model.save('mnist_model.h5')

    # 评估模型
    test_loss, test_accuracy = model.evaluate(test_images, test_labels)
    print(f'Test accuracy: {test_accuracy}')


if __name__ == "__main__":
    main()

