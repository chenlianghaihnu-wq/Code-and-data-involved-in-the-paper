import sys
import random
import numpy as np
import tensorflow as tf
from PIL.ImageMath import imagemath_max
from tensorflow import keras
from tensorflow.keras.callbacks import ReduceLROnPlateau
from tensorflow.keras.datasets import mnist
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from tensorflow.keras.utils import to_categorical
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix
from tensorflow.keras.models import load_model
from tensorflow.keras import regularizers,layers
from tensorflow.keras.layers import Dropout
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.preprocessing.image import ImageDataGenerator

from msgpack_numpy import tostr
import torch
import torch.nn.functional as F

train_images = np.load("train_i_k2*2.npy")
test_images = np.load("test_i_k2*2.npy")
train_labels = np.load("train_labels.npy")
test_labels = np.load("test_labels .npy")
train_images.reshape(1000, 12, 12)
test_images.reshape(200, 12, 12)
train_labels = to_categorical(train_labels)
test_labels = to_categorical(test_labels)

def re_(a,c):
    random.seed(a)
    tf.random.set_seed(c)
    # train_labels = np.concatenate((train_labels, train_labels), axis=0)

    # 000000000 输出每个类别有多少个样本

    # print(train_labels.shape)
    # from collections import Counter
    #
    # # 统计每个标签的出现次数
    # label_counts = Counter(train_labels)
    #
    # # 输出每个标签对应的出现次数
    # for label, count in label_counts.items():
    #     print(f"标签 {label}: {count} 次")
    # print("test")
    # label_counts = Counter(test_labels)
    #
    # # 输出每个标签对应的出现次数
    # for label, count in label_counts.items():
    #     print(f"标签 {label}: {count} 次")
    #
    # sys.exit()

    # 构建卷积神经网络模型
    model = Sequential()
    # 卷积层和池化层（添加卷积和池化层来提取特征，避免过拟合）
    # model.add(Conv2D(32, (2, 2), activation='relu', input_shape=(12, 12,1)))
    # model.add(MaxPooling2D((2, 2))) #池化，降低图像尺寸
    model.add(Flatten())  # 一维化，模型输入
    model.add(Dense(900, activation='relu'))  # ,kernel_regularizer=regularizers.l2(0.001)
    # model.add(layers.BatchNormalization())
    # model.add(Dropout(0.25))  # 添加 Dropout，防止过拟合
    model.add(Dense(900, activation='relu'))  # 增加隐藏层
    # model.add(Dropout(0.25))  # 添加Dropout
    # model.add(Dense(100, activation='relu'))#,kernel_regularizer=regularizers.l2(0.01)
    model.add(Dense(10, activation='softmax'))

    # 定义带有标签平滑的损失函数
    loss = tf.keras.losses.CategoricalCrossentropy(label_smoothing=0.1)
    # 编译模型
    model.compile(optimizer='adam',
                  loss=loss,  # 'categorical_crossentropy',
                  metrics=['accuracy'])

    # 早停回调
    # early_stopping = EarlyStopping(monitor='val_loss', patience=3, restore_best_weights=True)

    # datagen = ImageDataGenerator(
    #     rotation_range=20,  # 随机旋转图像
    #     width_shift_range=0.2,  # 水平平移
    #     height_shift_range=0.2,  # 垂直平移
    #     shear_range=0.2,  # 剪切变换
    #     zoom_range=0.2,  # 随机缩放
    #     horizontal_flip=True,  # 随机水平翻转
    #     fill_mode='nearest'  # 填充模式
    # )
    # datagen.fit(train_images)
    # # 输入数据格式应该是numpy(50,28,28,1)
    # model.fit(datagen.flow(train_images, train_labels, batch_size=64), epochs=100)
    # early_stopping = EarlyStopping(monitor='val_loss', patience=5, restore_best_weights=True)
    # reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.2, patience=3, min_lr=1e-6)
    # print(train_images.shape)
    # print(train_labels.shape)
    # print(test_labels.shape)

    history=model.fit(train_images, train_labels, epochs=50, batch_size=64,
                         validation_data=(test_images, test_labels), verbose=1)

    # model.fit(train_ima
    # ges, train_labels, epochs=20, batch_size=64,
    #           validation_split=0.1, verbose=1)  # ,callbacks=[early_stopping, reduce_lr]
    # model.fit(datagen.flow(train_images, train_labels, batch_size=32),
    #           epochs=10,
    #           validation_split=0.1,
    #           callbacks=[early_stopping])
    # 保存模型
    # model.save('mnist_model.h5')
    # 从 history 对象中提取 val_accuracy
    val_accuracy = history.history['val_accuracy']
    # 找到最高的 val_accuracy
    max_val_accuracy = max(val_accuracy)
    print(f"最高的验证集准确率: {max_val_accuracy}")
    # # 评估模型
    # test_loss, test_accuracy = model.evaluate(test_images, test_labels)
    #
    # print(f'Test accuracy: {test_accuracy}')
    # print(f'Test_loss:{test_loss}')

    import pandas as pd

    # 假设 history 是通过 model.fit() 得到的 History 对象
    history_data = history.history  # 获取训练过程中的数据
    # 创建一个 DataFrame，将训练过程中的各项数据保存到 DataFrame
    history_df = pd.DataFrame({
        'epoch': range(1, len(history_data['loss']) + 1),
        'train_loss': history_data['loss'],
        'train_accuracy': history_data['accuracy'],
        'val_loss': history_data['val_loss'],
        'val_accuracy': history_data['val_accuracy']
    })

    # 保存 DataFrame 到 Excel 文件
    history_df.to_excel('mnist_1000_200_qcnn2*2_2025_2_27.xlsx', index=False)

    print("训练历史已保存到 'xlsx' 文件")

    sys.exit()
    ############return test_accuracy

    test_predictions = model.predict(test_images)  # 预测得到的概率值

    # 真实标签
    true_labels = np.argmax(test_labels, axis=1)  # 获取真实标签

    # 获取每个样本预测的最大概率
    predicted_probabilities = np.max(test_predictions, axis=1)

    # 生成混淆矩阵，格式调整为包含概率的矩阵
    cm = confusion_matrix(true_labels, np.argmax(test_predictions, axis=1))

    # 计算每个类别的概率
    cm_probabilities = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]  # 正规化为概率

    # 可视化混淆矩阵
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm_probabilities, annot=True, fmt='.2f', cmap='Blues', xticklabels=np.arange(10),
                yticklabels=np.arange(10))
    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')
    plt.title('Confusion Matrix with Probabilities')
    plt.show()

a=re_(6,20)







